import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  LayoutAnimation,
  Platform,
  UIManager,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';

if (Platform.OS === 'android') {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

export default function App({ navigation }) {
  const [groupName, setGroupName] = useState('');
  const [groupDescription, setGroupDescription] = useState('');
  const [cards, setCards] = useState([{ question: '', answer: '', expanded: true }]);

  const toggleExpand = (index) => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    const updated = [...cards];
    updated[index].expanded = !updated[index].expanded;
    setCards(updated);
  };

  const addCard = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setCards([...cards, { question: '', answer: '', expanded: true }]);
  };

  const removeCard = (index) => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    const updated = [...cards];
    updated.splice(index, 1);
    setCards(updated);
  };

  const updateCard = (index, field, value) => {
    const updated = [...cards];
    updated[index][field] = value;
    setCards(updated);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      
      {/* زر الرجوع كأيقونة */}
      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.navigate('home')}>
        <Ionicons name="arrow-back" size={28} color="#6a1b9a" />
      </TouchableOpacity>

      <Text style={styles.title}>انشئ الفلاش كارد الخاصة بك</Text>

      <TextInput
        style={styles.input}
        placeholder="اسم المجموعة"
        value={groupName}
        onChangeText={setGroupName}
      />

      <TextInput
        style={[styles.input, { height: 70 }]}
        placeholder="وصف المجموعة"
        value={groupDescription}
        onChangeText={setGroupDescription}
        multiline
      />

      {cards.map((card, index) => (
        <View key={index} style={styles.card}>
          {/* عنوان البطاقة وزر التوسيع */}
          <TouchableOpacity
            style={styles.cardHeader}
            onPress={() => toggleExpand(index)}
          >
            <Text style={styles.cardTitle}>البطاقة {index + 1}</Text>
            <Ionicons
              name={card.expanded ? 'chevron-up' : 'chevron-down'}
              size={22}
              color="#444"
            />
          </TouchableOpacity>

          {/* محتوى البطاقة */}
          {card.expanded && (
            <>
              <TextInput
                placeholder="السؤال"
                value={card.question}
                onChangeText={(text) => updateCard(index, 'question', text)}
                style={styles.input}
              />

              <TextInput
                placeholder="الجواب"
                value={card.answer}
                onChangeText={(text) => updateCard(index, 'answer', text)}
                style={styles.input}
              />

              <TouchableOpacity
                style={styles.removeBtn}
                onPress={() => removeCard(index)}
              >
                <Ionicons name="trash-outline" size={20} color="#b00020" />
              </TouchableOpacity>
            </>
          )}
        </View>
      ))}

      {/* زر الإضافة تحت آخر كرت */}
      <TouchableOpacity style={styles.addBtn} onPress={addCard}>
        <Ionicons name="add" size={24} color="#fff" />
      </TouchableOpacity>

      {/* زر الحفظ */}
      <TouchableOpacity style={styles.submitBtn} onPress={() => navigation.navigate('home')}>
        <Text style={styles.submitText}>حفظ</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingBottom: 50,
    backgroundColor: '#f7f7f7',
  },
  backBtn: {
    alignSelf: 'flex-start',
    marginBottom: 10,
  },
  title: {
    fontSize: 20,
    textAlign: 'center',
    marginBottom: 20,
    fontWeight: 'bold',
    color: '#4a148c',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    padding: 10,
    marginVertical: 8,
    backgroundColor: '#fff',
  },
  card: {
    borderWidth: 1,
    borderColor: '#aaa',
    borderRadius: 12,
    padding: 10,
    marginTop: 15,
    backgroundColor: '#fff',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cardTitle: {
    fontWeight: 'bold',
    fontSize: 16,
    color: '#333',
  },
  removeBtn: {
    marginTop: 10,
    alignSelf: 'flex-end',
  },
  addBtn: {
    backgroundColor: '#6a1b9a',
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'flex-start',
    marginTop: 15,
  },
  submitBtn: {
    backgroundColor: '#3D2A59',
    padding: 15,
    borderRadius: 12,
    marginTop: 30,
    alignItems: 'center',
  },
  submitText: {
    color: '#fff',
    fontSize: 18,
  },
});
