import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const { width } = Dimensions.get('window');
const purpleColor = '#3D2A59';

export default function LectureScreen() {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.headerWrapper} />

      {/* Icons Row */}
      <View style={styles.headerIconsContainer}>
  <View style={styles.leftIcons}>
    <TouchableOpacity
      onPress={() => navigation.navigate('LearningModeScreen')}
      style={styles.iconButton}
    >
      <Ionicons name="arrow-back-outline" size={20} color={purpleColor} />
    </TouchableOpacity>

    <TouchableOpacity
      onPress={() => navigation.navigate('CreateFlashCardScreen')}
      style={styles.iconButton}
    >
      <Ionicons name="document-text-outline" size={20} color={purpleColor} />
    </TouchableOpacity>
  </View>

  <TouchableOpacity
    onPress={() => navigation.navigate('LearningModeScreen')}
    style={styles.iconButton}
  >
    <Ionicons name="close-outline" size={20} color={purpleColor} />
  </TouchableOpacity>
</View>


      {/* Content */}
      <View style={styles.content}>
        <Text style={styles.lectureTitle}>Lecture 01: Introduction to Mobile Development</Text>
        <View style={styles.grayLine} />

        {/* Counter */}
        <View style={styles.counterWrapper}>
          <Text style={styles.counterText}>0%</Text>
        </View>

        <TouchableOpacity style={styles.mainButton} onPress={() => navigation.navigate('FlashcardsScreen')}>
          <Text style={styles.buttonText}>ابدأ التعلم</Text>
        </TouchableOpacity>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Market Demand</Text>
          <Text style={styles.sectionContent}>
            Huge market and demand for app developers due to increasing mobile users.
          </Text>
        </View>
      </View>

      {/* Footer */}
      <View style={styles.footerWrapper}>
        <TouchableOpacity onPress={() => navigation.navigate('setting')}>
          <Ionicons name="settings-outline" size={30} color="#FFFFFF" />
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('home')}>
          <Ionicons name="home-outline" size={30} color="#FFFFFF" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  headerWrapper: {
    backgroundColor: purpleColor,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    height: 40,
  },
  headerIconsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginTop: 29,
    marginBottom: 9,
  },
  leftIcons: {
    flexDirection: 'row',
    gap: 8,
  },
  iconButton: {
    backgroundColor: '#EDF4FF',
    padding: 8,
    borderRadius: 30,
  },
  content: {
    flex: 1,
    padding: 25,
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  lectureTitle: {
    fontSize: 20,
    fontWeight: '600',
    alignSelf: 'flex-start',
    color: '#000',
    marginBottom: 20,
    marginTop: 40,
  },
  grayLine: {
    height: 4,
    backgroundColor: '#C4C4C4',
    width: width - 50,
    marginBottom: 30,
  },
  counterWrapper: {
    backgroundColor: '#E8E8E8',  
    borderRadius: 20,
    paddingHorizontal: 25,
    paddingVertical: 6,
    marginBottom: 20,
  },
  counterText: {
    fontSize: 16,
    color: purpleColor,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  mainButton: {
    backgroundColor: '#533E7A',
    paddingVertical: 14,
    width: 280,            
    borderRadius: 10,      
    marginBottom: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  section: {
    width: width - 50,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: purpleColor,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: purpleColor,
    textAlign: 'center',
    marginBottom: 10,
  },
  sectionContent: {
    fontSize: 14,
    color: '#333',
    textAlign: 'center',
    lineHeight: 20,
  },

  
  footerWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 15,
    height: 70,
    backgroundColor: '#3D2A59',
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    position: 'absolute',
    bottom: 30, 
    width: '100%',
    zIndex: 10, 
  },
  
  
});




