import React, { useRef, useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

export default function OTPScreen({ navigation, route }) {
  const { email } = route.params; // نستقبل الإيميل من resetpassword
  const [otp, setOtp] = useState(['', '', '', '']);
  const [timer, setTimer] = useState(30);
  const inputs = useRef([]);

  useEffect(() => {
    let countdown;
    if (timer > 0) {
      countdown = setTimeout(() => setTimer(timer - 1), 1000);
    }
    return () => clearTimeout(countdown);
  }, [timer]);

  const handleChange = (text, index) => {
    if (/^\d$/.test(text) || text === '') {
      const newOtp = [...otp];
      newOtp[index] = text;
      setOtp(newOtp);

      if (text !== '' && index < otp.length - 1) {
        inputs.current[index + 1].focus();
      }
    }
  };

  const handleResend = () => {
    console.log('إعادة إرسال الرمز إلى:', email);
    setOtp(['', '', '', '']);
    setTimer(30);
    Alert.alert('تم', 'تمت إعادة إرسال الرمز إلى بريدك الإلكتروني.');
  };

  const handleSubmit = () => {
    const enteredCode = otp.join('');
    if (enteredCode.length !== 4) {
      Alert.alert('خطأ', 'يرجى إدخال رمز مكون من ٤ أرقام.');
      return;
    }
    // هنا نفترض أن الكود دائماً صحيح (لأننا نستخدم Mock API بدون إرسال فعلي)
    navigation.navigate('reset', { email });
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
        <FontAwesome name="arrow-left" size={25} color="#3D2A59" />
      </TouchableOpacity>

      <View style={styles.topSection}>
        <Text style={styles.headerText}>رمز التحقق</Text>
      </View>

      <View style={styles.formSection}>
        <Text style={styles.subtitle}>
          أدخل الرمز المكون من 4 أرقام المرسل إلى بريدك الإلكتروني.
        </Text>

        <View style={styles.otpContainer}>
          {otp.map((digit, index) => (
            <TextInput
              key={index}
              ref={(ref) => (inputs.current[index] = ref)}
              style={styles.otpBox}
              keyboardType="number-pad"
              maxLength={1}
              onChangeText={(text) => handleChange(text, index)}
              value={digit}
              textAlign="center"
              textAlignVertical="center"
            />
          ))}
        </View>

        <TouchableOpacity style={styles.loginButton} onPress={handleSubmit}>
          <Text style={styles.loginText}>تحقق</Text>
        </TouchableOpacity>

        {timer > 0 ? (
          <Text style={styles.timerText}>
            يمكنك إعادة الإرسال خلال <Text style={{ fontWeight: 'bold' }}>{timer} ثانية</Text>
          </Text>
        ) : (
          <TouchableOpacity onPress={handleResend}>
            <Text style={styles.resendText}>إعادة إرسال الرمز</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  backButton: {
    position: 'absolute',
    top: 40,
    left: 20,
    zIndex: 10,
    backgroundColor: '#eee',
    padding: 10,
    borderRadius: 30,
  },
  topSection: {
    backgroundColor: '#3D2A59',
    paddingTop: 80,
    paddingBottom: 50,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 40,
    borderBottomRightRadius: 40,
  },
  headerText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  formSection: {
    padding: 20,
    alignItems: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#333',
    marginBottom: 24,
    textAlign: 'center',
    lineHeight: 24,
  },
  otpContainer: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    width: '80%',
    marginBottom: 30,
  },
  otpBox: {
    backgroundColor: '#fff',
    width: 55,
    height: 60,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#b8a3d6',
    fontSize: 24,
    fontWeight: 'bold',
    color: '#3D2A59',
    textAlign: 'center',
    textAlignVertical: 'center',
  },
  loginButton: {
    backgroundColor: '#b8a3d6',
    paddingVertical: 15,
    borderRadius: 30,
    marginTop: 10,
    width: '100%',
    alignItems: 'center',
  },
  loginText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  resendText: {
    color: '#3D2A59',
    fontWeight: 'bold',
    fontSize: 16,
    marginTop: 20,
  },
  timerText: {
    marginTop: 20,
    color: '#999',
    fontSize: 15,
  },
});
