import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  I18nManager,
} from 'react-native';
import { MaterialIcons, FontAwesome } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { apiRequest } from './API';

I18nManager.forceRTL(true);

export default function SignUp() {
  const navigation = useNavigation();
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleRegister = async () => {
    if (!username || !email || !password || !confirmPassword) {
      alert('الرجاء تعبئة جميع الحقول');
      return;
    }

    if (!validateEmail(email)) {
      alert('يرجى إدخال بريد إلكتروني صحيح');
      return;
    }

    if (password !== confirmPassword) {
      alert('كلمة المرور وتأكيد كلمة المرور غير متطابقين');
      return;
    }

    if (password.length < 8) {
      alert('كلمة المرور يجب أن تكون 8 أحرف على الأقل');
      return;
    }

    if (!/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/[0-9]/.test(password)) {
      alert('كلمة المرور يجب أن تحتوي على حرف كبير وحرف صغير ورقم');
      return;
    }

    setLoading(true);
    try {
      await apiRequest('/users', 'POST', {
        username,
        email,
        password,
        notificationsEnabled: true,
      });
      alert('تم إنشاء الحساب بنجاح');
      navigation.replace('signin');
    } catch (error) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.topSection}>
        <View style={styles.headerRow}>
          <Text style={styles.headerText}>سجل اشتراكك في{"\n"}تذَكّر</Text>
          <TouchableOpacity onPress={() => navigation.navigate('signin')} style={styles.backButton}>
            <FontAwesome name="arrow-left" size={24} color="#3D2A59" />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.formSection}>
        <Text style={styles.label}>اسم المستخدم</Text>
        <TextInput
          placeholder="مثال: jinnan"
          style={styles.input}
          textAlign="right"
          value={username}
          onChangeText={setUsername}
        />

        <Text style={styles.label}>الإيميل</Text>
        <TextInput
          placeholder="example@gmail.com"
          keyboardType="email-address"
          style={styles.input}
          textAlign="right"
          value={email}
          onChangeText={setEmail}
        />

        <Text style={styles.label}>كلمة المرور</Text>
        <View style={styles.passwordContainer}>
          <TextInput
            secureTextEntry={!passwordVisible}
            style={styles.input}
            textAlign="right"
            value={password}
            onChangeText={setPassword}
          />
          <TouchableOpacity onPress={() => setPasswordVisible(!passwordVisible)} style={styles.eyeIcon}>
            <MaterialIcons name={passwordVisible ? 'visibility' : 'visibility-off'} size={24} color="gray" />
          </TouchableOpacity>
        </View>

        <Text style={styles.label}>تأكيد كلمة المرور</Text>
        <TextInput
          secureTextEntry
          style={styles.input}
          textAlign="right"
          value={confirmPassword}
          onChangeText={setConfirmPassword}
        />

        <TouchableOpacity style={styles.loginButton} onPress={handleRegister} disabled={loading}>
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.loginText}>تسجيل</Text>
          )}
        </TouchableOpacity>

        <View style={styles.signupContainer}>
          <Text style={styles.noAccount}>لديك حساب بالفعل؟</Text>
          <TouchableOpacity onPress={() => navigation.navigate('signin')}>
            <Text style={styles.signup}>سجّل الدخول</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  topSection: {
    backgroundColor: '#3D2A59',
    paddingTop: 80,
    paddingBottom: 40,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 40,
    borderBottomRightRadius: 40,
  },
  headerRow: {
    flexDirection: 'row-reverse', // يعكس ترتيب العناصر: نص يمين، سهم يسار
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backButton: {
    backgroundColor: '#eee',
    padding: 10,
    borderRadius: 30,
  },
  headerText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'right',
    flex: 1,
    marginLeft: 10,
  },
  formSection: { padding: 20 },
  label: {
    color: '#3D2A59',
    marginBottom: 5,
    marginTop: 20,
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  input: {
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    fontSize: 16,
    paddingVertical: 8,
    paddingRight: 10,
  },
  passwordContainer: {
    position: 'relative',
    justifyContent: 'center',
  },
  eyeIcon: {
    position: 'absolute',
    left: 0,
    top: 8,
  },
  loginButton: {
    backgroundColor: '#b8a3d6',
    paddingVertical: 15,
    borderRadius: 30,
    marginTop: 30,
    alignItems: 'center',
  },
  loginText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  signupContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  noAccount: { color: '#aaa' },
  signup: { color: '#3D2A59', fontWeight: 'bold', marginLeft: 5 },
});
