import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { UserProvider } from './context/UserContext'; // تأكد من المسار الصحيح

// استيراد جميع الصفحات التي تحتاجها في التنقل
import FirstPage from './firstpage';
import InfoApp from './infoapp';
import Terms from './terms'; // تأكد من أن هذا هو اسم الملف الصحيح
import SignIn from './signin';
import SignUp from './signup';
import ForgotPasswordScreen from './resetpassword';
import OTPScreen from './otp';
import ResetPasswordScreen from './reset';
import HomeFile from './home';
import Setting from './setting';
import CreateFlashcardScreen from './CreateFlashcardScreen';
import StatsScreen from './StatsScreen';
import LearningModeScreen from './LearningModeScreen';
import LectureScreen from './LectureScreen';
import FlashcardsScreen from './FlashcardsScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    // تغليف التطبيق بمزود UserContext
    <UserProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="firstpage" screenOptions={{ headerShown: false }}>
          <Stack.Screen name="firstpage" component={FirstPage} />
          <Stack.Screen name="infoapp" component={InfoApp} />
          <Stack.Screen name="terms" component={Terms} />
          <Stack.Screen name="signup" component={SignUp} />
          <Stack.Screen name="signin" component={SignIn} />
          <Stack.Screen name="resetpassword" component={ForgotPasswordScreen} />
          <Stack.Screen name="otp" component={OTPScreen} />
          <Stack.Screen name="reset" component={ResetPasswordScreen} />
          <Stack.Screen name="home" component={HomeFile} />
          <Stack.Screen name="setting" component={Setting} />
          <Stack.Screen name="CreateFlashcardScreen" component={CreateFlashcardScreen} />
          <Stack.Screen name="Stats" component={StatsScreen} />
          <Stack.Screen name="LearningMode" component={LearningModeScreen} />
          <Stack.Screen name="LectureScreen" component={LectureScreen} />
          <Stack.Screen name="FlashcardsScreen" component={FlashcardsScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </UserProvider>
  );
}
