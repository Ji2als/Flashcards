import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions, SafeAreaView, Platform } from 'react-native';
import { Ionicons, FontAwesome5, MaterialIcons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');

export default function LearningModeScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>

      {/* سهم العودة إلى StatsScreen */}
      <TouchableOpacity
        onPress={() => navigation.navigate('StatsScreen')}
        style={styles.backArrow}
      >
        <Ionicons name="arrow-back-outline" size={28} color="#fff" />
      </TouchableOpacity>

      <View style={styles.topOval} />

      {/* الترحيب */}
      <View style={styles.header}>
        <Text style={styles.welcomeText}>مرحباً لَيان! 👋</Text>
        <Text style={styles.subText}>مرحباً بعودتك</Text>
      </View>

      {/* الخيارات */}
      <View style={styles.card}>
        <Text style={styles.questionText}>كيف تريد أن تختبر تعلمك؟</Text>

        <TouchableOpacity style={styles.optionGreen} onPress={() => navigation.navigate('MCQ')}>
          <View style={styles.iconTextRow}>
            <View style={styles.greenCheckCircle}>
              <Ionicons name="checkmark" size={12} color="#fff" />
            </View>
            <Text style={[styles.optionText, { color: '#00C851', marginLeft: 8 }]} numberOfLines={1}>
              أسئلة اختيار من متعدد (MCQ)
            </Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={styles.optionBlue} onPress={() => navigation.navigate('LectureScreen')}>
          <View style={styles.iconTextRow}>
            <FontAwesome5 name="brain" size={18} color="#007BFF" />
            <Text style={[styles.optionText, { color: '#007BFF', marginLeft: 6 }]}>بطاقة تعليمية</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={styles.optionPurple} onPress={() => navigation.navigate('Summary')}>
          <View style={styles.iconTextRow}>
            <MaterialIcons name="description" size={18} color="#3D2A59" />
            <Text style={[styles.optionText, { color: '#3D2A59', marginLeft: 6 }]}>ملخص</Text>
          </View>
        </TouchableOpacity>
      </View>

      {/* شريط التنقل السفلي */}
      <View style={styles.navbar}>
        <TouchableOpacity onPress={() => navigation.navigate('setting')}>
          <Ionicons name="settings-outline" size={28} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('home')}>
          <Ionicons name="home-outline" size={28} color="#fff" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'android' ? 40 : 0,
  },

  backArrow: {
    position: 'absolute',
    top: Platform.OS === 'android' ? 40 : 60,
    left: 20,
    zIndex: 10,
  },

  topOval: {
    position: 'absolute',
    top: -80,
    left: -70,
    width: width * 1.4,
    height: 220,
    borderBottomRightRadius: width,
    borderBottomLeftRadius: width,
    backgroundColor: '#3D2A59',
    zIndex: -1,
  },

  header: {
    alignItems: 'center',
    marginBottom: 90,
  },

  welcomeText: {
    fontSize: 25,
    fontWeight: 'bold',
    color: '#fff',
    marginTop: 50,
  },

  subText: {
    fontSize: 19,
    color: '#fff',
    marginTop: 5,
  },

  card: {
    backgroundColor: '#fff',
    borderRadius: 40,
    padding: 40,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 10,
  },

  questionText: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 15,
    textAlign: 'center',
  },

  optionGreen: {
    borderWidth: 1,
    borderColor: '#00C851',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 15,
    alignItems: 'center',
  },

  optionBlue: {
    borderWidth: 1,
    borderColor: '#007BFF',
    padding: 12,
    borderRadius: 8,
    marginBottom: 15,
    alignItems: 'center',
  },

  optionPurple: {
    borderWidth: 1,
    borderColor: '#3D2A59',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },

  optionText: {
    fontSize: 16,
    fontWeight: '500',
    flexShrink: 1,
  },

  iconTextRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  greenCheckCircle: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#00C851',
    justifyContent: 'center',
    alignItems: 'center',
  },

  navbar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#3D2A59',
    padding: 15,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 60,
    paddingBottom: Platform.OS === 'ios' ? 30 : 15,
  },
});
