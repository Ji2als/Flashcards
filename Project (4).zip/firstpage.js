import React, { useEffect } from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';
import { StatusBar } from 'expo-status-bar';

export default function FirstPage({ navigation }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.replace('infoapp'); 
    }, 3000); // 10 seconds

    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Image
          source={require('./assets/brain.png')}
          style={styles.logo}
          resizeMode="cover"
        />
      </View>
      <Text style={styles.title}>تذكر</Text>
      <StatusBar style="light" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
     flex: 1,
    backgroundColor: '#3D2A59',
    padding: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    width: 250,
    height: 250,
    borderRadius: 125,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 5 },
  },
  logo: {
    width: '100%',
    height: '100%',
  },
  title: {
    color: 'white',
    fontSize: 50,
    fontWeight: 'bold',
  },
});