import React from 'react';
import { StyleSheet, Text, View, Image, Pressable } from 'react-native';

export default function InfoApp({ navigation }) {
  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Image
          source={require('./assets/brain.png')}
          style={styles.logo}
          resizeMode="contain"
        />
      </View>

      <Text style={styles.description}>
        اجعل مذاكرتك أسهل وأكثر فعالية مع "تذَكّر"! يتيح لك التطبيق تحويل ملفات PDF إلى فلاش كارد تفاعلية لمساعدتك على استرجاع المعلومات بسرعة وتنظيم دراستك بذكاء.{"\n"}
        ودّع المذاكرة التقليدية وجرب تجربة تعليمية ممتعة مع "تذَكّر"! 🚀
      </Text>

      <Pressable style={styles.button} onPress={() => navigation.navigate('terms')}>
        <Text style={styles.buttonText}>ابدأ الآن</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#3D2A59',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  logoContainer: {
    width: 250,
    height: 250,
    borderRadius: 125,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 5 },
    backgroundColor: '#fff',
  },
  logo: {
    width: '100%',
    height: '100%',
  },
  description: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 28,
    marginBottom: 40,
  },
  button: {
    backgroundColor: '#b8a3d6',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 25,
  },
  buttonText: {
    color: '#3D2A59',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
