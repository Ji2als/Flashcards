import { Alert } from 'react-native';
import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { AntDesign, Feather, Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native';
const flashcards = [
  { id: 1, question: "Why is mobile app development important?", answer: "Mobile app development offers a hot career option for coders." },
  { id: 2, question: "What are the main reasons businesses need a mobile app?", answer: "Increase visibility, boost sales, improve engagement, gain customer insights, enhance communication, and provide a better user experience." },
  { id: 3, question: "Career Opportunity", answer: "The growing number of mobile users and high demand for app developers make it a lucrative and evolving field." },
  { id: 4, question: "Popular Mobile Platforms", answer: "The two dominant platforms are Android and iOS." },
  { id: 5, question: "Native vs Cross-Platform", answer: "Native apps are developed for a specific platform. Cross-platform apps are developed to run on multiple platforms using a single codebase." },
  { id: 6, question: "What is React Native?", answer: "React Native is a popular framework for building cross-platform mobile apps using JavaScript and React." },
  { id: 7, question: "What are APIs?", answer: "APIs allow different software components to communicate with each other." },
  { id: 8, question: "Frontend vs Backend", answer: "Frontend is what users see (UI), Backend is server-side logic, databases, and APIs." },
  { id: 9, question: "Why is UI/UX important?", answer: "Good UI/UX enhances user satisfaction and drives more engagement." },
  { id: 10, question: "What is Expo?", answer: "Expo is a framework and platform for universal React applications, making development easier and faster." },
];

export default function FlashcardsScreen() {
  const navigation = useNavigation();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [masteredCount, setMasteredCount] = useState(0);
  const [learningCount, setLearningCount] = useState(0);
  const [showSummary, setShowSummary] = useState(false);

  const currentCard = flashcards[currentIndex];

  const handleMastered = () => {

  setMasteredCount(prev => prev + 1);
    Alert.alert('رائع!', 'لقد أتقنت هذه البطاقة ✅');

  nextCard();
};



  const handleLearning = () => {
    setLearningCount(prev => prev + 1);
    nextCard();

    
  };

  const nextCard = () => {
    if (currentIndex < flashcards.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setShowAnswer(false);
    } else {
      setShowSummary(true);
    }
  };

  const prevCard = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      setShowAnswer(false);
    }
  };

  const resetSession = () => {
    setCurrentIndex(0);
    setMasteredCount(0);
    setLearningCount(0);
    setShowAnswer(false);
    setShowSummary(false);
  };

  if (showSummary) {
    return (
<SafeAreaView style={[styles.container, { justifyContent: 'center', alignItems: 'center', backgroundColor: '#F5F5FA', flexGrow: 1 }]}>
<View style={[styles.topOval, ]} />
<View style={styles.resultContainer}>

        <Ionicons name="trophy-outline" size={100} color="#3D2A59" style={{ marginTop: 20 }} />
        
        <Text style={[styles.summaryTitle, { marginTop: 20 }]}>أحسنت! 🎉</Text>
        <Text style={{ fontSize: 16, color: '#3D2A59', marginTop: 10 }}>هذه نتائجك النهائية</Text>

        <View style={styles.resultsContainer}>
          <View style={styles.resultCard}>
            <Text style={styles.resultNumber}>{masteredCount}</Text>
            <Text style={styles.resultLabel}>عدد الإتقان</Text>
          </View>
          <View style={styles.resultCard}>
            <Text style={styles.resultNumber}>{learningCount}</Text>
            <Text style={styles.resultLabel}>ما زلت أتعلم</Text>
          </View>
        </View>

        <TouchableOpacity onPress={() => { resetSession(); navigation.navigate('home'); }} style={styles.homeButton}>
          <Text style={styles.homeButtonText}> المحاولة مره أخرى </Text>
        </TouchableOpacity>
      </View>
      </SafeAreaView>

    );
  }

  return (
    <View style={styles.container}>
      {/* الهيدر */}
      <View style={styles.topOval} />
      <View style={styles.header}>
        {/* يسار */}
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <TouchableOpacity onPress={() => navigation.navigate('LectureScreen')} style={styles.headerIconButton}>
            <AntDesign name="arrowleft" size={20} color="#3D2A59" />
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('CreateFlashCardScreen')} style={styles.headerIconButton}>
            <Ionicons name="document-text-outline" size={20} color="#3D2A59" />
          </TouchableOpacity>
        </View>

        {/* يمين */}
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <TouchableOpacity onPress={() => navigation.navigate('setting')} style={styles.headerIconButton}>
            <Feather name="settings" size={20} color="#3D2A59" />
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('LearningModeScreen')} style={styles.headerIconButton}>
            <AntDesign name="close" size={20} color="#3D2A59" />
          </TouchableOpacity>
        </View>
      </View>

      {/* عنوان المحاضرة */}
      <View style={styles.titleContainer}>
        <Text style={styles.lectureTitle}>Lecture 01_Introduction to Mobile Development</Text>
        <View style={styles.titleUnderline} />
      </View>

      {/* الكرت */}
      <View style={styles.cardWrapper}>
        <View style={styles.sideCard} />
        <View style={styles.card}>
          <Text style={styles.questionText}>{currentCard.question}</Text>

          {showAnswer && (
            <View style={styles.answerBox}>
              <Text style={styles.answerText}>{currentCard.answer}</Text>
            </View>
          )}

          <TouchableOpacity onPress={() => setShowAnswer(prev => !prev)} style={styles.arrowButton}>
            <AntDesign name={showAnswer ? 'up' : 'down'} size={20} color="#3D2A59" />
          </TouchableOpacity>

          {showAnswer && (
            <View style={styles.masteryButtons}>
               <TouchableOpacity onPress={handleMastered} style={[styles.masteryButton, { backgroundColor: '#D9CBE3' }]}>
                <Text style={[styles.masteryText, { color: '#3D2A59' }]}>أتقنت</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={handleLearning} style={[styles.masteryButton, { backgroundColor: '#D9CBE3' }]}>
                <Text style={[styles.masteryText, { color: '#3D2A59' }]}>ما زلت أتعلم</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
        <View style={styles.sideCard} />
      </View>

      {/* التقدم */}
      <Text style={styles.progressText}>{currentIndex + 1} / {flashcards.length}</Text>
      <View style={styles.progressBarBackground}>
        <View style={[styles.progressBarFill, { width: `${((currentIndex + 1) / flashcards.length) * 100}%` }]} />
      </View>

      {/* أزرار التنقل */}
      <View style={styles.navButtons}>
  {/* زر التالي يمين */}
  <TouchableOpacity onPress={nextCard} disabled={currentIndex === flashcards.length - 1} style={[styles.navButton, currentIndex === flashcards.length - 1 && { opacity: 0.5 }, { marginRight: 50 }]}>
    <Text style={styles.navButtonText}>التالي</Text>
    <Ionicons name="arrow-forward" size={20} color="#3D2A59" />
  </TouchableOpacity>

  {/* زر التراجع يسار */}
  <TouchableOpacity onPress={prevCard} disabled={currentIndex === 0} style={styles.backButtonWrapper}>
    <View style={styles.backButton}>
      <AntDesign name="arrowleft" size={20} color="#3D2A59" />
    </View>
    <Text style={styles.backButtonText}>تراجع</Text>
  </TouchableOpacity>
</View>




      {/* الشريط السفلي */}
      <View style={[styles.container, { flex: 1 }]}></View>
      <View style={styles.bottomBar}>
        <TouchableOpacity onPress={() => navigation.navigate('setting')}>
          <Ionicons name="settings-outline" size={30} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('home')}>
          <Ionicons name="home-outline" size={30} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const { width } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: { flex: 1,  backgroundColor: '#F5F5FA', justifyContent: 'flex-start', paddingTop: 40,  
    paddingBottom: 0, },
    resultContainer: {
      flex: 1,
      marginTop: 100, 
      height: 50,
      backgroundColor: '#F5F5FA',
      alignItems: 'center',
      paddingTop: 40, 
    },
  topOval: {
    width: width,
    height: 40,
    backgroundColor: '#3D2A59',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  header: { marginTop: 30, marginHorizontal: 20, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  headerIconButton: { backgroundColor: '#E0EAF8', padding: 9, borderRadius: 50 },
  titleContainer: { marginHorizontal: 20, marginTop: 120 },
  lectureTitle: { fontSize: 16, fontWeight: '600', color: '#000',marginTop: -20  },
  titleUnderline: { height: 6, backgroundColor: '#D3D3D3', marginTop: 8, width: '100%' },
  cardWrapper: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 30 },
  sideCard: { width: 40, height: 150, borderRadius: 20, backgroundColor: '#A085C1', marginHorizontal: 8 },
  card: { backgroundColor: '#3D2A59', borderRadius: 20, width: width * 0.6, paddingVertical: 40, paddingHorizontal: 15, alignItems: 'center', position: 'relative' },
  questionText: { fontSize: 16, color: '#fff', fontWeight: '600', textAlign: 'center', marginBottom: 10 },
  answerBox: { backgroundColor: '#D9CBE3', borderRadius: 12, padding: 12, marginTop: 15 },
  answerText: { fontSize: 14, color: '#3D2A59', textAlign: 'center' },
  arrowButton: { backgroundColor: '#EEF1F3', padding: 10, borderRadius: 50, position: 'absolute', bottom: -20, alignSelf: 'center' },
  masteryButtons: { flexDirection: 'row', justifyContent: 'center', marginTop: 25, gap: 20 },
  masteryButton: { backgroundColor: '#3D2A59', paddingVertical: 10, paddingHorizontal: 20, borderRadius: 10 },
  masteryText: { color: '#fff', fontSize: 15, fontWeight: '600' },
  progressText: { textAlign: 'center', fontSize: 15, color: '#3D2A59', marginTop: 50, fontWeight: '500' },
  progressBarBackground: { height: 8, backgroundColor: '#E0D5EF', borderRadius: 10, overflow: 'hidden', marginHorizontal: 30, marginTop: 8 },
  progressBarFill: { height: 8, backgroundColor: '#3D2A59' },
  navButtons: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 20, marginHorizontal: 30 },
  navButton: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, paddingHorizontal: 20, borderRadius: 10, backgroundColor: 'transparent' },
  navButtonText: { color: '#3D2A59', fontSize: 16, fontWeight: '600', marginHorizontal: 5 },
  bottomBar: { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 15, backgroundColor: '#3D2A59', height: 80, borderTopLeftRadius: 20, borderTopRightRadius: 20, position: 'absolute', bottom:0, width: '100%' },
  summaryTitle: { fontSize: 22, fontWeight: '700', color: '#3D2A59', textAlign: 'center' },
  homeButton: { marginTop: 40, backgroundColor: '#3D2A59', paddingVertical: 12, paddingHorizontal: 25, borderRadius: 10 },
  homeButtonText: { color: '#fff', fontSize: 16, fontWeight: '600', textAlign: 'center' },
  resultsContainer: { flexDirection: 'row', justifyContent: 'space-around', marginTop: 30, width: '80%' },
  resultCard: { backgroundColor: '#E0EAF8', width: 130, height: 130, borderRadius: 20, justifyContent: 'center', alignItems: 'center', shadowColor: '#000', shadowOpacity: 0.1, shadowOffset: { width: 0, height: 2 }, shadowRadius: 8, elevation: 5 },
  resultNumber: { fontSize: 36, fontWeight: '700', color: '#3D2A59' },
  resultLabel: { fontSize: 16, color: '#3D2A59', marginTop: 8, fontWeight: '500' },
  backButtonWrapper: { alignItems: 'center' },
  backButton: { backgroundColor: '#E0EAF8', padding: 10, borderRadius: 50, justifyContent: 'center', alignItems: 'center', marginBottom: 5 },
  backButtonText: { color: '#3D2A59', fontSize: 14, fontWeight: '600' },
});





