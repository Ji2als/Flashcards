import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

export default function TermsAndPrivacyScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>
      {/* رأس الصفحة */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.navigate('infoapp')} style={styles.backButton}>
          <FontAwesome name="arrow-left" size={24} color="#3D2A59" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>شروط الاستخدام وسياسة الخصوصية</Text>
      </View>

      {/* المحتوى */}
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.termsText}>
          مرحبًا بك في تطبيق "تذكّر"! قبل الاستمرار في استخدام التطبيق، يرجى قراءة شروط الاستخدام وسياسة الخصوصية التالية بعناية:
        </Text>

        <Text style={styles.sectionTitle}>1. قبول الشروط</Text>
        <Text style={styles.termsText}>
          باستخدامك للتطبيق، فإنك توافق على الالتزام بهذه الشروط. إذا كنت لا توافق، يرجى عدم استخدام التطبيق.
        </Text>

        <Text style={styles.sectionTitle}>2. تغييرات الشروط</Text>
        <Text style={styles.termsText}>
          نحن نحتفظ بالحق في تعديل هذه الشروط في أي وقت. يُنصح بمراجعة هذه الشروط بانتظام لتظل على اطلاع بأية تغييرات تطرأ.
        </Text>

        <Text style={styles.sectionTitle}>3. استخدام التطبيق</Text>
        <Text style={styles.termsText}>
          يجب عليك استخدام التطبيق بطريقة قانونية ومحترمة ولا تتسبب في أي ضرر أو انتهاك لحقوق الآخرين.
        </Text>

        <Text style={styles.sectionTitle}>4. إخلاء المسؤولية</Text>
        <Text style={styles.termsText}>
          لا نتحمل أي مسؤولية عن أي أضرار أو خسائر قد تحدث نتيجة لاستخدام التطبيق. أنت المسؤول الوحيد عن استخدامك للتطبيق.
        </Text>

        <Text style={styles.sectionTitle}>5. البيانات الشخصية</Text>
        <Text style={styles.termsText}>
          نحن نلتزم بحماية خصوصيتك. نقوم بجمع البيانات الأساسية المطلوبة لتحسين تجربة المستخدم في التطبيق، ولكننا لن نشارك هذه البيانات مع أطراف خارجية دون إذن منك.
        </Text>

        <Text style={styles.sectionTitle}>6. سياسة الخصوصية</Text>
        <Text style={styles.termsText}>
          نلتزم بحماية خصوصية مستخدمينا بشكل كامل. يتم جمع البيانات لاستخدامها فقط في تحسين وظائف التطبيق وتقديم الخدمة بكفاءة.
        </Text>

        <Text style={styles.termsText}>
          نحن لا نستخدم أو نشارك بياناتك الشخصية لأغراض تجارية. جميع البيانات التي يتم جمعها محفوظة بشكل آمن ولا يتم الوصول إليها إلا من قبل فريقنا المسؤول عن إدارة التطبيق.
        </Text>
      </ScrollView>

      {/* زر الموافقة */}
      <TouchableOpacity style={styles.acceptButton} onPress={() => navigation.navigate('signin')}>
        <Text style={styles.acceptButtonText}>أوافق على الشروط وسياسة الخصوصية</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    backgroundColor: '#3D2A59',
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    flexDirection: 'row-reverse', // السهم يسار والنص يمين
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 30,
    marginLeft: 10, // بدل marginRight لأننا استخدمنا row-reverse
  },
  headerTitle: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
  },
  content: {
    padding: 20,
    paddingBottom: 40,
  },
  termsText: {
    color: '#3D2A59',
    fontSize: 16,
    lineHeight: 26,
    marginBottom: 10,
    textAlign: 'right',
  },
  sectionTitle: {
    color: '#4B0082',
    fontWeight: 'bold',
    fontSize: 18,
    marginTop: 20,
    marginBottom: 5,
    textAlign: 'right',
  },
  acceptButton: {
    backgroundColor: '#b8a3d6',
    margin: 20,
    paddingVertical: 15,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  acceptButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
