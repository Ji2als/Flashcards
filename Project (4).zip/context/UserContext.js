import React, { createContext, useState, useEffect, useContext } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const storedToken = await AsyncStorage.getItem('token');
        const storedUser = await AsyncStorage.getItem('user');
        const storedNotifications = await AsyncStorage.getItem('notificationsEnabled');

        if (storedToken && storedUser) {
          setToken(storedToken);
          const parsedUser = JSON.parse(storedUser);
          setUser(parsedUser);
          setNotificationsEnabled(storedNotifications ? JSON.parse(storedNotifications) : false);
        }
      } catch (error) {
        console.log('خطأ في تحميل بيانات المستخدم:', error);
      }
    };

    loadUserData();
  }, []);

  const login = async (data) => {
    try {
      setToken(data.token);
      setUser(data.user);
      setNotificationsEnabled(data.user.notificationsEnabled ?? false);

      await AsyncStorage.setItem('token', data.token);
      await AsyncStorage.setItem('user', JSON.stringify(data.user));
      await AsyncStorage.setItem('notificationsEnabled', JSON.stringify(data.user.notificationsEnabled ?? false));
    } catch (error) {
      console.log('خطأ أثناء تسجيل الدخول:', error);
    }
  };

  const logout = async () => {
    try {
      setToken(null);
      setUser(null);
      setNotificationsEnabled(false);
      await AsyncStorage.multiRemove(['token', 'user', 'notificationsEnabled']);
    } catch (error) {
      console.log('خطأ أثناء تسجيل الخروج:', error);
    }
  };

  const updatePassword = (newPassword) => {
    if (!user) return;

    const updatedUser = { ...user, password: newPassword };
    setUser(updatedUser);
    AsyncStorage.setItem('user', JSON.stringify(updatedUser));
  };

  const updateNotificationsSetting = async (enabled) => {
    if (!user) return;

    try {
      // تحديث الحالة محلياً
      setNotificationsEnabled(enabled);

      // تحديث في AsyncStorage
      await AsyncStorage.setItem('notificationsEnabled', JSON.stringify(enabled));

      // إرسال تحديث للسيرفر (مثلاً API أو Mock)
      await fetch('https://your-backend.com/update-notifications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          userId: user.id,
          notificationsEnabled: enabled,
        }),
      });

      // اختياري: تحدّث نسخة الuser المخزنة لو تبغى
      const updatedUser = { ...user, notificationsEnabled: enabled };
      setUser(updatedUser);
      await AsyncStorage.setItem('user', JSON.stringify(updatedUser));
    } catch (error) {
      console.log('خطأ أثناء تحديث الإشعارات:', error);
    }
  };

  return (
    <UserContext.Provider value={{
      user,
      token,
      notificationsEnabled,
      login,
      logout,
      updatePassword,
      updateNotificationsSetting,
    }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => useContext(UserContext);
