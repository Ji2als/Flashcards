
import React, { useState, useEffect } from 'react';

import {

View,

Text,

SafeAreaView,

StyleSheet,

TouchableOpacity,

Platform,

Dimensions,

KeyboardAvoidingView,

ScrollView,

Modal,

Pressable,

FlatList,

Image,

TextInput,

} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import * as DocumentPicker from 'expo-document-picker';

import NetInfo from '@react-native-community/netinfo';


const fileIcon = require('./assets/files.png'); 


export default function HomeFile({ navigation }) {

const [modalVisible, setModalVisible] = useState(false);

const [isConnected, setIsConnected] = useState(true);

const [isNetworkAlertVisible, setIsNetworkAlertVisible] = useState(false);

const [searchQuery, setSearchQuery] = useState('');


const folders = [

{ id: '1', name: 'lecture13 file-system' },

{ id: '2', name: 'ch08-intrusion detection' },

{ id: '3', name: 'hr_security and incident handling' },

];


const [filteredFolders, setFilteredFolders] = useState(folders);


useEffect(() => {

const unsubscribe = NetInfo.addEventListener(state => {

setIsConnected(state.isConnected);

});

return () => unsubscribe();

}, []);


const handleSearch = (text) => {

setSearchQuery(text);

const filtered = folders.filter((folder) =>

folder.name.toLowerCase().includes(text.toLowerCase())

);

setFilteredFolders(filtered);

};


const renderFolder = ({ item }) => (

<TouchableOpacity

style={styles.folderCard}

onPress={() => navigation.navigate('LectureScreen', { folderId: item.id, folderName: item.name })}

>

<Image source={fileIcon} style={styles.folderImage} />

<Text style={styles.folderText}>{item.name}</Text>

</TouchableOpacity>

);


const handleAddPress = () => {

setModalVisible(true);

};


const pickDocument = async () => {

if (!isConnected) {

setIsNetworkAlertVisible(true);

return;

}

try {

const result = await DocumentPicker.getDocumentAsync({

type: '*/*',

copyToCacheDirectory: true,

multiple: false,

});

if (result.type !== 'cancel') {

console.log('📎 تم اختيار الملف:', result);

}

} catch (error) {

console.error('خطأ أثناء اختيار الملف:', error);

} finally {

setModalVisible(false);

}

};


return (

<KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>

<SafeAreaView style={styles.container}>

<ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>


{/* Search Bar */}

<View style={styles.searchContainer}>

<Ionicons name="search-outline" size={24} color="#5B4B8A" style={styles.searchIcon} />

<TextInput

style={styles.searchInput}

placeholder="ابحث عن المجلدات..."

placeholderTextColor="#8a8a8a"

value={searchQuery}

onChangeText={handleSearch}

/>

</View>


{/* Modal */}

<Modal transparent visible={modalVisible} animationType="fade" onRequestClose={() => setModalVisible(false)}>

<Pressable style={styles.modalOverlay} onPress={() => setModalVisible(false)}>

<View style={styles.modalContent}>

<TouchableOpacity style={styles.modalButton} onPress={pickDocument}>

<Text style={styles.modalButtonText}>📎 إرفاق ملف</Text>

</TouchableOpacity>

<TouchableOpacity

style={styles.modalButton}

onPress={() => {

setModalVisible(false);

navigation.navigate('CreateFlashcardScreen');

}}

>

<Text style={styles.modalButtonText}>✏️ إنشاء يدوي</Text>

</TouchableOpacity>

</View>

</Pressable>

</Modal>


{/* Folders Grid */}

<FlatList

data={filteredFolders}

keyExtractor={(item) => item.id}

renderItem={renderFolder}

numColumns={2}

contentContainerStyle={styles.folderList}

/>


<View style={{ height: 120 }} />

</ScrollView>


{/* Bottom Navigation */}

<View style={styles.bottomNav}>

<TouchableOpacity onPress={() => navigation.navigate('setting')}>

<Ionicons name="settings-outline" size={28} color="#fff" />

</TouchableOpacity>


<TouchableOpacity onPress={() => navigation.navigate('home')}>

<Ionicons name="home-outline" size={28} color="#fff" />

</TouchableOpacity>

</View>


{/* Center Floating Add Button */}

<View style={styles.centerAddButtonWrapper}>

<TouchableOpacity style={styles.centerAddButton} onPress={handleAddPress}>

<Ionicons name="add" size={32} color="#5B4B8A" />

</TouchableOpacity>

</View>


{/* Network Alert */}

{isNetworkAlertVisible && !isConnected && (

<View style={styles.networkAlert}>

<Text style={styles.networkAlertText}>

⚠️ غير متصل بالإنترنت! يرجى الاتصال بالإنترنت لإرفاق الملفات.

</Text>

<TouchableOpacity onPress={() => setIsNetworkAlertVisible(false)}>

<Ionicons name="close-circle" size={24} color="#fff" />

</TouchableOpacity>

</View>

)}

</SafeAreaView>

</KeyboardAvoidingView>

);

}


const styles = StyleSheet.create({

flex: { flex: 1 },

container: { flex: 1, backgroundColor: '#3D2A59' },

scrollContent: { padding: 24, paddingBottom: 140, alignItems: 'center' },

searchContainer: {

flexDirection: 'row',

alignItems: 'center',

backgroundColor: '#fff',

borderRadius: 25,

paddingHorizontal: 16,

paddingVertical: 8,

marginBottom: 16,

width: '90%',

},

searchIcon: { marginRight: 8 },

searchInput: { flex: 1, fontSize: 16, color: '#333' },

folderList: { alignItems: 'center' },

folderCard: {

backgroundColor: '#fff',

borderRadius: 15,

padding: 16,

margin: 8,

width: (Dimensions.get('window').width - 60) / 2,

alignItems: 'center',

elevation: 5,

shadowColor: '#000',

shadowOpacity: 0.1,

shadowOffset: { width: 0, height: 2 },

shadowRadius: 6,

},

folderImage: {

width: 60,

height: 60,

marginBottom: 10,

resizeMode: 'contain',

},

folderText: {

fontSize: 14,

color: '#333',

textAlign: 'center',

fontWeight: 'bold',

},

modalOverlay: {

flex: 1,

backgroundColor: 'rgba(0,0,0,0.5)',

justifyContent: 'center',

alignItems: 'center',

},

modalContent: {

backgroundColor: '#fff',

borderRadius: 12,

padding: 20,

width: 280,

},

modalButton: { paddingVertical: 12, alignItems: 'center' },

modalButtonText: { fontSize: 18, color: '#5B4B8A' },

bottomNav: {

flexDirection: 'row',

justifyContent: 'space-between',

alignItems: 'center',

backgroundColor: '#7159A8',

paddingHorizontal: 40,

paddingVertical: 12,

borderTopLeftRadius: 25,

borderTopRightRadius: 25,

position: 'absolute',

bottom: 0,

left: 0,

right: 0,

height: 70,

paddingBottom: Platform.OS === 'android' ? 12 : 30,

elevation: 8,

},

centerAddButtonWrapper: {

position: 'absolute',

bottom: 35,

alignSelf: 'center',

zIndex: 20,

},

centerAddButton: {

width: 70,

height: 70,

borderRadius: 35,

backgroundColor: '#fff',

justifyContent: 'center',

alignItems: 'center',

elevation: 8,

shadowColor: '#000',

shadowOpacity: 0.2,

shadowOffset: { width: 0, height: 2 },

shadowRadius: 6,

},

networkAlert: {

position: 'absolute',

top: 50,

width: '100%',

backgroundColor: '#f44336',

padding: 10,

alignItems: 'center',

zIndex: 20,

},

networkAlertText: { color: '#fff', fontSize: 16 },

});