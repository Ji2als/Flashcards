import React from 'react';

import { View, Text, StyleSheet, TouchableOpacity, Image, ScrollView, SafeAreaView } from 'react-native';

import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';


export default function StatsScreen({ navigation }) {

return (

<SafeAreaView style={styles.container}>

<ScrollView contentContainerStyle={styles.scrollContent}>

{/* Header */}

<View style={styles.header}>

<TouchableOpacity onPress={() => navigation.goBack()} style={styles.backIcon}>

<Ionicons name="arrow-back" size={24} color="#fff" />

</TouchableOpacity>

<Image

source={require('./assets/profile.png')}

style={styles.avatar}

/>

<Text style={styles.username}>layan saleh</Text>

</View>


{/* Stats */}

<View style={styles.statsBox}>

<View style={styles.statItem}>

<MaterialCommunityIcons name="flash" size={24} color="#3D2A59" />

<Text style={styles.statValue}>37</Text>

<Text style={styles.statLabel}>الفلاش كاردز المضافة</Text>

</View>


<View style={styles.statItem}>

<MaterialCommunityIcons name="clock-outline" size={24} color="#3D2A59" />

<Text style={styles.statValue}>122+</Text>

<Text style={styles.statLabel}>الساعات المقضية</Text>

</View>

</View>


{/* Chart */}

<View style={styles.chartContainer}>

<Text style={styles.chartTitle}>Screen Time</Text>

<Text style={styles.chartSubtitle}>٣ ساعات، ١٦ دقيقة اليوم</Text>

<Image

source={require('./assets/chart.png')} // تأكد من وجود الصورة في المسار الصحيح

style={styles.chartImage}

resizeMode="contain"

/>

</View>

</ScrollView>


{/* Footer */}

<View style={styles.footer}>

<TouchableOpacity onPress={() => navigation.navigate('Home')}>

<Ionicons name="home-outline" size={28} color="#fff" />

</TouchableOpacity>

<TouchableOpacity onPress={() => navigation.navigate('Settings')}>

<Ionicons name="settings-outline" size={28} color="#fff" />

</TouchableOpacity>

</View>

</SafeAreaView>

);

}


const styles = StyleSheet.create({

container: {

flex: 1,

backgroundColor: '#fff',

},

scrollContent: {

paddingBottom: 80, 

},

header: {

backgroundColor: '#3D2A59',

paddingTop: 70,

paddingBottom: 40,

alignItems: 'center',

borderBottomLeftRadius: 40,

borderBottomRightRadius: 40,

position: 'relative',

},

backIcon: {

position: 'absolute',

left: 20,

top: 60,

},

avatar: {

width: 85,

height: 85,

borderRadius: 42.5,

marginBottom: 8,

},

username: {

color: '#fff',

fontSize: 18,

fontWeight: 'bold',

},


statsBox: {

flexDirection: 'row',

backgroundColor: '#fff',

marginHorizontal: 20,

padding: 25,

borderRadius: 20,

marginTop: -30,

shadowColor: '#000',

shadowOpacity: 0.1,

shadowOffset: { width: 0, height: 5 },

shadowRadius: 10,

elevation: 5,

justifyContent: 'space-between',

},

statItem: {

alignItems: 'center',

flex: 1,

},

statValue: {

fontSize: 20,

fontWeight: 'bold',

color: '#3D2A59',

marginTop: 5,

},

statLabel: {

fontSize: 13,

color: '#999',

marginTop: 4,

textAlign: 'center',

},


chartContainer: {

alignItems: 'center',

marginTop: 40,

paddingHorizontal: 20,

marginBottom: 10,

},

chartTitle: {

fontSize: 16,

color: '#3D2A59',

fontWeight: 'bold',

marginBottom: 5,

},

chartSubtitle: {

color: '#888',

marginBottom: 15,

},

chartImage: {

width: '100%',

height: 150,

},


footer: {

height: 70,

backgroundColor: '#3D2A59',

flexDirection: 'row',

justifyContent: 'space-around',

alignItems: 'center',

borderTopLeftRadius: 30,

borderTopRightRadius: 30,

position: 'absolute',

bottom: 30,

width: '100%',

},

});






