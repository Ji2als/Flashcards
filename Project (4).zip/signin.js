import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator, I18nManager } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { apiRequest } from './API'; // تأكد من المسار
import { useUser } from './context/UserContext';

I18nManager.forceRTL(true);

export default function SignIn({ navigation }) {
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useUser();

  const handleLogin = async () => {
    setLoading(true);
    try {
      const users = await apiRequest('/users', 'GET');
      const foundUser = users.find(
        user => user.username === username && user.password === password
      );

      if (foundUser) {
       login({ user: foundUser, token: null }); // حفظ بيانات المستخدم في الكونتكست
        navigation.replace('home'); // التوجه للصفحة الرئيسية
      } else {
        alert('اسم المستخدم أو كلمة المرور غير صحيحة');
      }
    } catch (error) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.topSection}>
        <Text style={styles.headerText}>
          مرحباً بعودتك{"\n"}سجّل دخولك إلى تذَكّر
        </Text>
      </View>

      <View style={styles.formSection}>
        <Text style={styles.label}>اسم المستخدم</Text>
        <TextInput
          style={styles.input}
          textAlign="right"
          value={username}
          onChangeText={setUsername}
        />

        <Text style={styles.label}>كلمة المرور</Text>
        <View style={styles.passwordContainer}>
          <TextInput
            secureTextEntry={!passwordVisible}
            style={styles.input}
            textAlign="right"
            value={password}
            onChangeText={setPassword}
          />
          <TouchableOpacity
            onPress={() => setPasswordVisible(!passwordVisible)}
            style={styles.eyeIcon}
          >
            <MaterialIcons
              name={passwordVisible ? 'visibility' : 'visibility-off'}
              size={24}
              color="gray"
            />
          </TouchableOpacity>
        </View>

        <TouchableOpacity onPress={() => navigation.navigate('resetpassword')}>
          <Text style={styles.forgot}>نسيت كلمة المرور؟</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.loginButton}
          onPress={handleLogin}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.loginText}>تسجيل الدخول</Text>
          )}
        </TouchableOpacity>

        <View style={styles.signupContainer}>
          <Text style={styles.noAccount}>ليس لديك حساب؟</Text>
          <TouchableOpacity onPress={() => navigation.navigate('signup')}>
            <Text style={styles.signup}>اشترك الآن</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  topSection: {
    backgroundColor: '#3D2A59',
    paddingTop: 80,
    paddingBottom: 50,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 40,
    borderBottomRightRadius: 40,
  },
  headerText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  formSection: { padding: 20 },
  label: {
    color: '#3D2A59',
    marginBottom: 5,
    marginTop: 20,
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  input: {
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    fontSize: 16,
    paddingVertical: 8,
    paddingRight: 10,
  },
  passwordContainer: {
    position: 'relative',
    justifyContent: 'center',
  },
  eyeIcon: {
    position: 'absolute',
    left: 0,
    top: 8,
  },
  forgot: {
    color: '#3D2A59',
    textAlign: 'right',
    marginTop: 10,
  },
  loginButton: {
    backgroundColor: '#b8a3d6',
    paddingVertical: 15,
    borderRadius: 30,
    marginTop: 30,
    alignItems: 'center',
  },
  loginText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  signupContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  noAccount: { color: '#aaa' },
  signup: { color: '#3D2A59', fontWeight: 'bold', marginLeft: 5 },
});
