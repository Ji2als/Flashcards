import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  FlatList,
} from 'react-native';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';

const files = [
  { id: '1', name: 'lecture13 file-system', icon: 'book' },
  { id: '2', name: 'ch08-intrusion detection', icon: 'shield' },
  { id: '3', name: 'hr_security and incident handling', icon: 'book' },
];

export default function FilesScreen() {
  const [showOptions, setShowOptions] = useState(false);
  const [screen, setScreen] = useState('home'); // home | upload | manual

  const renderItem = ({ item }) => (
    <View style={styles.fileCard}>
      <View style={styles.iconContainer}>
        {item.icon === 'book' ? (
          <Ionicons name="book-outline" size={24} color="#5E4193" />
        ) : (
          <MaterialIcons name="security" size={24} color="#5E4193" />
        )}
      </View>
      <Text style={styles.fileName}>{item.name}</Text>
    </View>
  );

  const renderHome = () => (
    <>
      <TextInput
        placeholder="البحث"
        style={styles.searchInput}
        placeholderTextColor="#888"
        textAlign="right"
      />
      <FlatList
        contentContainerStyle={styles.filesContainer}
        data={files}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        numColumns={2}
      />

      {showOptions && (
        <View style={styles.optionsContainer}>
          <TouchableOpacity
            style={styles.optionButton}
            onPress={() => {
              setShowOptions(false);
              setScreen('manual');
            }}
          >
            <Text style={styles.optionText}>انشاء بشكل يدوي</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.optionButton}
            onPress={() => {
              setShowOptions(false);
              setScreen('upload');
            }}
          >
            <Text style={styles.optionText}>ارفاق ملف</Text>
          </TouchableOpacity>
        </View>
      )}

      <TouchableOpacity
        style={styles.addButton}
        onPress={() => setShowOptions(!showOptions)}
      >
        <Text style={styles.addText}>+</Text>
      </TouchableOpacity>
    </>
  );

  const renderUpload = () => (
    <View style={styles.innerScreen}>
      <Text style={styles.sectionTitle}>ارفاق ملف</Text>
      <Text style={styles.sectionSub}>هنا تقدر تختار ملف من الجهاز لرفعه</Text>

      <TouchableOpacity onPress={() => setScreen('home')} style={styles.backBtn}>
        <Text style={styles.optionText}>رجوع</Text>
      </TouchableOpacity>
    </View>
  );

  const renderManual = () => (
    <View style={styles.innerScreen}>
      <Text style={styles.sectionTitle}>انشاء بشكل يدوي</Text>
      <Text style={styles.sectionSub}>هنا تقدر تنشئ بطاقة فلاش بشكل يدوي</Text>

      <TouchableOpacity onPress={() => setScreen('home')} style={styles.backBtn}>
        <Text style={styles.optionText}>رجوع</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      {screen === 'home' && renderHome()}
      {screen === 'upload' && renderUpload()}
      {screen === 'manual' && renderManual()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#4B2C74', paddingTop: 50 },
  searchInput: {
    backgroundColor: '#fff',
    borderRadius: 20,
    paddingHorizontal: 20,
    height: 40,
    marginHorizontal: 20,
    marginBottom: 20,
    textAlign: 'right',
  },
  filesContainer: {
    paddingHorizontal: 20,
    paddingBottom: 100,
    gap: 20,
  },
  fileCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 15,
    margin: 10,
    width: '42%',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 3,
  },
  iconContainer: {
    alignItems: 'flex-end',
  },
  fileName: {
    marginTop: 20,
    textAlign: 'center',
    fontSize: 14,
    color: '#000',
  },
  addButton: {
    position: 'absolute',
    bottom: 30,
    alignSelf: 'center',
    backgroundColor: '#fff',
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addText: {
    color: '#5E4193',
    fontSize: 28,
    fontWeight: 'bold',
  },
  optionsContainer: {
    position: 'absolute',
    bottom: 100,
    alignSelf: 'center',
    alignItems: 'center',
  },
  optionButton: {
    backgroundColor: '#fff',
    paddingVertical: 10,
    paddingHorizontal: 25,
    marginVertical: 5,
    borderRadius: 8,
  },
  optionText: {
    fontSize: 16,
    color: '#333',
    fontWeight: '600',
  },
  innerScreen: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  sectionSub: {
    fontSize: 16,
    color: '#eee',
    textAlign: 'center',
    marginBottom: 30,
  },
  backBtn: {
    backgroundColor: '#fff',
    paddingVertical: 10,
    paddingHorizontal: 25,
    borderRadius: 8,
  },
});