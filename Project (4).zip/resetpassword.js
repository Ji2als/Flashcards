import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { apiRequest } from './API';

export default function ForgotPasswordScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSendCode = async () => {
    if (!email.includes('@')) {
      Alert.alert('تنبيه', 'يرجى إدخال بريد إلكتروني صحيح.');
      return;
    }
    setLoading(true);
    try {
      const users = await apiRequest('/users', 'GET');
      const foundUser = users.find(user => user.email === email);
      if (foundUser) {
        navigation.navigate('otp', { email });
      } else {
        Alert.alert('خطأ', 'البريد الإلكتروني غير موجود');
      }
    } catch (error) {
      Alert.alert('خطأ', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={() => navigation.navigate('signin')}
        style={styles.backButton}
      >
        <FontAwesome name="arrow-left" size={25} color="#3D2A59" />
      </TouchableOpacity>

      <View style={styles.topSection}>
        <Text style={styles.headerText}>نسيت كلمة المرور؟</Text>
      </View>

      <View style={styles.formSection}>
        <Text style={styles.subtitle}>
          أدخل بريدك الإلكتروني وسنرسل لك رمز تحقق لإعادة تعيين كلمة المرور.
        </Text>

        <Text style={styles.label}>البريد الإلكتروني</Text>
        <TextInput
          style={styles.input}
          placeholder="example@email.com"
          placeholderTextColor="#aaa"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          textAlign="right"
        />

        <TouchableOpacity style={styles.loginButton} onPress={handleSendCode} disabled={loading}>
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.loginText}>إرسال رمز التحقق</Text>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  backButton: {
    position: 'absolute',
    top: 40,
    left: 20,
    zIndex: 10,
    backgroundColor: '#eee',
    padding: 10,
    borderRadius: 20,
  },
  topSection: {
    backgroundColor: '#3D2A59',
    paddingTop: 80,
    paddingBottom: 50,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 40,
    borderBottomRightRadius: 40,
  },
  headerText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  formSection: { padding: 20 },
  subtitle: {
    fontSize: 16,
    color: '#333',
    marginBottom: 24,
    textAlign: 'right',
    lineHeight: 24,
  },
  label: {
    color: '#3D2A59',
    marginBottom: 5,
    marginTop: 20,
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  input: {
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    fontSize: 16,
    paddingVertical: 8,
    paddingRight: 10,
    textAlign: 'right',
  },
  loginButton: {
    backgroundColor: '#b8a3d6',
    paddingVertical: 15,
    borderRadius: 30,
    marginTop: 30,
    alignItems: 'center',
  },
  loginText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
