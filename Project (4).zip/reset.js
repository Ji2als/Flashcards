import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { FontAwesome } from '@expo/vector-icons';
import { apiRequest } from './API';

const themeColors = {
  card: '#3D2A59',
};

export default function ResetPasswordScreen({ navigation, route }) {
  const { email } = route.params; // جلب الإيميل من صفحة otp أو resetpassword
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [hidePassword, setHidePassword] = useState(true);
  const [hideConfirmPassword, setHideConfirmPassword] = useState(true);
  const [passwordStrength, setPasswordStrength] = useState({ level: '', color: '' });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    evaluatePasswordStrength(password);
  }, [password]);

  const evaluatePasswordStrength = (pwd) => {
    let score = 0;
    if (pwd.length >= 8) score++;
    if (/[A-Z]/.test(pwd)) score++;
    if (/[a-z]/.test(pwd)) score++;
    if (/[0-9]/.test(pwd)) score++;
    if (/[^A-Za-z0-9]/.test(pwd)) score++;

    if (score <= 2) {
      setPasswordStrength({ level: 'ضعيف', color: 'red' });
    } else if (score <= 4) {
      setPasswordStrength({ level: 'متوسط', color: 'orange' });
    } else {
      setPasswordStrength({ level: 'قوي', color: 'green' });
    }
  };

  const handleSave = async () => {
    if (!password || !confirmPassword) {
      Alert.alert('تنبيه', 'يرجى تعبئة كل الحقول.');
      return;
    }

    if (password.length < 8) {
      Alert.alert('كلمة المرور ضعيفة', 'يجب أن تتكون كلمة المرور من 8 أحرف على الأقل.');
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert('خطأ', 'كلمتا المرور غير متطابقتين.');
      return;
    }

    setLoading(true);
    try {
      const users = await apiRequest('/users', 'GET');
      const foundUser = users.find(user => user.email === email);

      if (!foundUser) {
        Alert.alert('خطأ', 'لم يتم العثور على مستخدم بهذا البريد.');
        return;
      }

      await apiRequest(`/users/${foundUser.id}`, 'PUT', { ...foundUser, password });

      Alert.alert('تم بنجاح', 'تم تغيير كلمة المرور بنجاح');
      navigation.navigate('signin');
    } catch (error) {
      Alert.alert('خطأ', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
        <FontAwesome name="arrow-left" size={25} color={themeColors.card} />
      </TouchableOpacity>

      <View style={styles.topSection}>
        <Text style={styles.headerText}>إعادة تعيين كلمة المرور</Text>
      </View>

      <View style={styles.formSection}>
        <Text style={styles.label}>كلمة المرور الجديدة</Text>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            secureTextEntry={hidePassword}
            placeholder="********"
            onChangeText={setPassword}
            value={password}
            textAlign="right"
          />
          <TouchableOpacity style={styles.eyeIcon} onPress={() => setHidePassword(!hidePassword)}>
            <Icon name={hidePassword ? 'eye-off-outline' : 'eye-outline'} size={22} color="#999" />
          </TouchableOpacity>
        </View>

        {password !== '' && (
          <Text style={{ color: passwordStrength.color, marginTop: 6, textAlign: 'right' }}>
            قوة كلمة المرور: {passwordStrength.level}
          </Text>
        )}

        <Text style={styles.label}>تأكيد كلمة المرور</Text>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            secureTextEntry={hideConfirmPassword}
            placeholder="********"
            onChangeText={setConfirmPassword}
            value={confirmPassword}
            textAlign="right"
          />
          <TouchableOpacity style={styles.eyeIcon} onPress={() => setHideConfirmPassword(!hideConfirmPassword)}>
            <Icon name={hideConfirmPassword ? 'eye-off-outline' : 'eye-outline'} size={22} color="#999" />
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.saveButton} onPress={handleSave} disabled={loading}>
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.saveText}>تأكيد</Text>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  backButton: {
    position: 'absolute',
    top: 40,
    left: 20,
    zIndex: 10,
    backgroundColor: '#eee',
    padding: 10,
    borderRadius: 30,
  },
  topSection: {
    backgroundColor: '#3D2A59',
    paddingTop: 80,
    paddingBottom: 50,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 40,
    borderBottomRightRadius: 40,
  },
  headerText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  formSection: { padding: 20 },
  label: {
    color: '#3D2A59',
    marginBottom: 8,
    marginTop: 20,
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  inputContainer: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  input: {
    flex: 1,
    fontSize: 16,
    paddingVertical: 8,
    paddingRight: 10,
    color: '#000',
  },
  eyeIcon: { padding: 8 },
  saveButton: {
    backgroundColor: '#b8a3d6',
    paddingVertical: 15,
    borderRadius: 30,
    marginTop: 40,
    alignItems: 'center',
  },
  saveText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
