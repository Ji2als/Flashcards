import React, { useState, useEffect } from 'react';
import { View, Text, SafeAreaView, StyleSheet, Switch, TouchableOpacity, Platform, Alert } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useUser } from './context/UserContext';
import { apiRequest } from './API';

if (Platform.OS === 'android') {
  Notifications.setNotificationChannelAsync('default', {
    name: 'default',
    importance: Notifications.AndroidImportance.MAX,
    vibrationPattern: [0, 250, 250, 250],
    lightColor: '#FF231F7C',
  });
}

export default function SettingsScreen() {
  const { user, token, updateNotificationsSetting } = useUser();
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const navigation = useNavigation();

  useEffect(() => {
    const loadNotificationSettings = async () => {
      const storedValue = await AsyncStorage.getItem('notificationsEnabled');
      if (storedValue !== null) {
        setNotificationsEnabled(JSON.parse(storedValue));
      } else if (user?.notifications !== undefined) {
        setNotificationsEnabled(user.notifications);
      }
    };
    loadNotificationSettings();
  }, [user]);

  const handleNotificationsToggle = async (value) => {
    setNotificationsEnabled(value);
    updateNotificationsSetting(value);
    await AsyncStorage.setItem('notificationsEnabled', JSON.stringify(value));

    try {
      if (user?.id) {
        await apiRequest(`/users/${user.id}`, 'PUT', {
          ...user,
          notifications: value,
        }, token);
      }

      if (value) {
        const permissionGranted = await registerForPushNotificationsAsync();
        if (permissionGranted) {
          await sendWelcomeNotification();
          Alert.alert('تم التفعيل ✅', 'تم تفعيل الإشعارات بنجاح.');
        } else {
          Alert.alert('تنبيه ⚠️', 'لم يتم منح صلاحية الإشعارات.');
        }
      } else {
        await Notifications.cancelAllScheduledNotificationsAsync();
        Alert.alert('تم الإيقاف ⛔', 'تم إيقاف الإشعارات.');
      }
    } catch (error) {
      Alert.alert('خطأ', 'تعذر تحديث الإعدادات.');
    }
  };

  async function registerForPushNotificationsAsync() {
    if (!Device.isDevice) {
      Alert.alert('تنبيه', 'الإشعارات تعمل فقط على الأجهزة الحقيقية');
      return false;
    }

    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (finalStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    return finalStatus === 'granted';
  }

  async function sendWelcomeNotification() {
    await Notifications.presentNotificationAsync({
      content: {
        title: "🌟 مرحبًا بك!",
        body: "اشتقنا لك! تعال راجع دروسك 📚",
        sound: 'default',
      },
    });
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <FontAwesome name="user-circle" size={50} color="#fff" />
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <FontAwesome name="arrow-left" size={24} color="#3D2A59" />
        </TouchableOpacity>
      </View>

      <Text style={[styles.title, { textAlign: 'center' }]}>الاعدادات</Text>

      <View style={styles.card}>
        <Text style={[styles.cardTitle, { textAlign: 'centerr' }]}>معلومات الحساب</Text>
        <Text style={[styles.label, { textAlign: 'left' }]}>اسم المستخدم</Text>
        <Text style={styles.placeholder}>{user?.username ?? 'غير متوفر'}</Text>
        <Text style={[styles.label, { textAlign: 'left' }]}>الإيميل</Text>
        <Text style={styles.placeholder}>{user?.email ?? 'غير متوفر'}</Text>
      </View>

      <View style={styles.card}>
        <View style={styles.rowBetween}>
          <View style={styles.row}>
            <FontAwesome name="globe" size={20} color="#4B0082" />
            <Text style={styles.sectionText}> اللغة </Text>
          </View>
          <Text style={styles.languageText}>العربية</Text>
        </View>
      </View>

      <View style={styles.card}>
        <View style={styles.rowBetween}>
          <View style={styles.row}>
            <FontAwesome name="moon-o" size={20} color="#4B0082" />
            <Text style={styles.sectionText}> الثيم </Text>
          </View>
          <Switch value={false} disabled />
        </View>
      </View>

      <View style={styles.card}>
        <View style={styles.rowBetween}>
          <View style={styles.row}>
            <FontAwesome name="bell" size={20} color="#4B0082" />
            <Text style={styles.sectionText}> الإشعارات </Text>
          </View>
          <Switch
            value={notificationsEnabled}
            onValueChange={handleNotificationsToggle}
            trackColor={{ false: '#767577', true: '#4B0082' }}
            thumbColor={notificationsEnabled ? '#fff' : '#f4f3f4'}
          />
        </View>
      </View>

      <TouchableOpacity
        style={styles.logoutButton}
        onPress={() => navigation.navigate('signin')}
      >
        <Text style={styles.logoutText}>تسجيل الخروج</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#3D2A59', padding: 20 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 20 },
  backButton: { backgroundColor: '#eee', padding: 10, borderRadius: 30 },
  title: { fontSize: 26, fontWeight: 'bold', color: '#fff', marginVertical: 20 },
  card: { backgroundColor: '#f4f4f4', borderRadius: 20, padding: 20, marginVertical: 10 },
  cardTitle: { fontWeight: 'bold', fontSize: 18, color: '#3D2A59', marginBottom: 10 },
  label: { fontWeight: 'bold', fontSize: 14, marginBottom: 5, color: '#333' },
  placeholder: { backgroundColor: '#eee', borderRadius: 8, padding: 8, fontSize: 14, textAlign: 'center', marginBottom: 10 },
  sectionText: { fontWeight: 'bold', fontSize: 16, marginLeft: 8, color: '#4B0082' },
  languageText: { fontWeight: 'bold', fontSize: 16, color: '#4B0082' },
  row: { flexDirection: 'row', alignItems: 'center' },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  logoutButton: { backgroundColor: '#f8f8f8', borderRadius: 20, paddingVertical: 15, marginTop: 30, alignItems: 'center' },
  logoutText: { color: '#4B0082', fontWeight: 'bold', fontSize: 16 },
});
